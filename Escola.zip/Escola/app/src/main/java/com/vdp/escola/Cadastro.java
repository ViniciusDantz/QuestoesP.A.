package com.vdp.escola;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Cadastro extends AppCompatActivity  implements View.OnClickListener {
    Button btn1;
    EditText nome;
    EditText idade;
    EditText cpf;
    EditText email;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1 = findViewById(R.id.cadastrar);
        nome = findViewById(R.id.edtnome);
        cpf = findViewById(R.id.edtcpf);
        idade = findViewById(R.id.edtidade);
        email = findViewById(R.id.edtemail);
    }

    @Override
    public void onClick(View view) {
        Intent i = new Intent(this, MainActivity.class);
        Aluno aluno = new Aluno(nome.toString(), cpf.toString(), email.toString(), idade.toString());
        i.putExtra("aluno", aluno);
        startActivity(i);

    }
}
