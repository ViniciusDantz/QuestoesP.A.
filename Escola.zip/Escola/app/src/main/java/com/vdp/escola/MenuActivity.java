package com.vdp.escola;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {
    Button btn1;
    Button btn2;
    Aluno aluno;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu);
        btn1 = findViewById(R.id.cadastro);
        btn2 = findViewById(R.id.consulta);
        if(getIntent() != null){
            Intent i = getIntent();
            aluno = i.getExtras().getParcelable("aluno");
        }
    }

    @Override
    public void onClick(View view) {
        if(view.getId() == btn1.getId()){
            Intent i = new Intent(this, Cadastro.class);
            startActivity(i);
        }else{
            Intent i = new Intent(this, MainActivity.class);
            if(getIntent() != null){
                i.putExtra("aluno", aluno);
            }
            startActivity(i);
        }
    }
}
