package com.vdp.escola;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class AlunoAdapter extends BaseAdapter {
    Context ctx;
    List<Aluno> alunos;

    public AlunoAdapter(List<Aluno> alunos, Context ctx) {
        this.alunos = alunos;
        this.ctx = ctx;
    }

    @Override
    public int getCount() {
        return alunos.size();
    }

    @Override
    public Object getItem(int position) {
        return alunos.get(position);
    }

    @Override
    public long getItemId(int positiom) {
        return positiom;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Aluno aluno = alunos.get(position);

        ViewHolder holder = null;

        if (convertView == null) {  // View nova, temos que criá-la
            Log.d("NGVL", "View Nova => position: " + position);
            convertView = LayoutInflater.from(ctx)
                    .inflate(R.layout.activity_main, null);
            holder = new ViewHolder();
            holder.idade = (TextView) convertView.findViewById(R.id.idade);
            holder.email = (TextView) convertView.findViewById(R.id.email);
            holder.cpf = (TextView) convertView.findViewById(R.id.cpf);
            holder.nome = (TextView) convertView.findViewById(R.id.nome);
            convertView.setTag(holder);
        }else{
            Log.d("NGVL", "View existente => position: "+ position);
            holder = (ViewHolder)convertView.getTag();
        }
        holder.nome.setText(aluno.nome);
        holder.idade.setText(aluno.idade);
        holder.cpf.setText(aluno.cpf);
        holder.email.setText(aluno.email);
        return convertView;
    }

    static class ViewHolder {
        TextView idade;
        TextView nome;
        TextView email;
        TextView cpf;
    }
}
