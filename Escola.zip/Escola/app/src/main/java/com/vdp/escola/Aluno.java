package com.vdp.escola;

import android.os.Parcel;
import android.os.Parcelable;

public class Aluno implements Parcelable {
    public String nome;
    public String cpf;
    public String email;
    public String idade;

    public Aluno(String nome, String cpf, String email, String idade) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.idade = idade;
    }

    protected Aluno(Parcel in) {
        nome = in.readString();
        cpf = in.readString();
        email = in.readString();
        idade = in.readString();
    }

    public static final Creator<Aluno> CREATOR = new Creator<Aluno>() {
        @Override
        public Aluno createFromParcel(Parcel in) {
            return new Aluno(in);
        }

        @Override
        public Aluno[] newArray(int size) {
            return new Aluno[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(nome);
        parcel.writeString(cpf);
        parcel.writeString(email);
        parcel.writeString(idade);
    }
}
