package com.vdp.escola;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    List<Aluno> alunos;
    AlunoAdapter adapter;
    ListView listView;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView)findViewById(R.id.list);
        listView.setEmptyView(findViewById(android.R.id.empty));

        alunos = new ArrayList<Aluno>();

        /*for (int i = 0; i < 10; i++) {
            alunos.add(new Aluno("Pedro" ,"123456789101", "pedrinhotododua@gmail.com", "10"));
            alunos.add(new Aluno("Lucas" ,"123456789101", "pedrinhotododua@gmail.com", "15"));
            alunos.add(new Aluno("Fernanda" ,"123456789101", "pedrinhotododua@gmail.com", "22"));
            alunos.add(new Aluno("Janeiro" ,"123456789101", "jandefevmarabril@gmail.com", "19"));
        }*/

        adapter = new AlunoAdapter(alunos, this);

        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view,
                                    int position, long id) {
                Aluno aluno = (Aluno) adapterView.getItemAtPosition(position);
                if (aluno != null) {
                    Toast.makeText(MainActivity.this, aluno.nome + "-" + aluno.idade,
                            Toast.LENGTH_SHORT).show();
                    alunos.remove(aluno);
                    adapter.notifyDataSetChanged();
                }
            }
        });


    }
}
