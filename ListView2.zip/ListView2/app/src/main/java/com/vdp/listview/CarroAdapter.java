package com.vdp.listview;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class CarroAdapter extends BaseAdapter {
    List<Carro> carros;
    Context context;

    public CarroAdapter(Context context, List<Carro> carros) {
        this.carros = carros;
        this.context = context;
    }

    @Override
    public int getCount() {
        return carros.size();
    }

    @Override
    public Object getItem(int i) {
        return carros.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        Carro carro = carros.get(i);
        ViewHolder holder = null;
        if(view == null){
            view = LayoutInflater.from(context)
                    .inflate(R.layout.activity_main, null);
            holder = new ViewHolder();
            holder.imgLogo = view.findViewById(R.id.image);
            holder.txtAno = view.findViewById(R.id.ano);
            holder.txtCombustivel = view.findViewById(R.id.combustivel);
            holder.txtModelo = view.findViewById(R.id.Modelo);
            view.setTag(holder);
        }else{
            holder = (ViewHolder) view.getTag();
        }

        Resources res = context.getResources();
        TypedArray logos =res.obtainTypedArray(R.array.carros);
        holder.imgLogo.setImageDrawable(
                logos.getDrawable(carro.fabricante));
        holder.txtModelo.setText(carro.modelo);
        holder.txtAno.setText(String.valueOf(carro.ano));
        holder.txtCombustivel.setText(
                (carro.gasolina ? "G" : "") +
                        (carro.etanol   ? "E" : ""));
        // Passo 4
        return view;
    }
    static class ViewHolder {
        ImageView imgLogo;
        TextView txtModelo;
        TextView txtAno;
        TextView txtCombustivel;
    }

}
