package com.VDP.atividadepa;

public class Produto {

    public String descricao;
    public int quantidade;
    public double valorUni;

    public Produto(String descricao, int quantidade, double valorUni) {
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.valorUni = valorUni;
    }

    public double getValorUni() {
        return valorUni;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public static double valorTotal(int quant, double valor){
        return quant * valor;
    }
}
